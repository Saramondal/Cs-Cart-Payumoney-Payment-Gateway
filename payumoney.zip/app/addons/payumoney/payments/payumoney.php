<?php
use Tygh\Registry;
if ( !defined('AREA') ) { die('Access denied'); }

// Return from payu website
if (defined('PAYMENT_NOTIFICATION')) {
	
	if($mode == 'success'){

		$sql = "INSERT INTO ?:payu SET order_id = '".$_REQUEST['order_id']."',response = '".serialize($_REQUEST)."'";
		db_query($sql);

		$pp_response = array();

		$status = $_REQUEST["status"];
		$firstname = $_REQUEST["firstname"];
		$amount = $_REQUEST["amount"];
		$txnid = $_REQUEST["txnid"];
		$posted_hash = $_REQUEST["hash"];
		$key = $_REQUEST["key"];
		$productinfo = $_REQUEST["productinfo"];
		$email = $_REQUEST["email"];
		$phone = $_REQUEST["phone"];

		$payment_id = db_get_field("SELECT payment_id FROM ?:orders WHERE order_id = ?i", $_REQUEST["order_id"]);
        $processor_data = fn_get_payment_method_data($payment_id);

		$salt = $processor_data['processor_params']['salt'];

		If (isset($_REQUEST["additionalCharges"])) {
			$additionalCharges = $_REQUEST["additionalCharges"];
			$retHashSeq = $additionalCharges.'|'.$salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
		} else {	  
			$retHashSeq = $salt.'|'.$status.'|||||||||||'.$email.'|'.$firstname.'|'.$productinfo.'|'.$amount.'|'.$txnid.'|'.$key;
		}
		$hash = hash("sha512", $retHashSeq);

		if ($hash != $posted_hash) {
			$pp_response["order_status"] = 'F';
            $pp_response["reason_text"] = "Fail: hash not matched";
            $pp_response['transaction_id'] = $txnid;
		} elseif($status == 'success'){
			$pp_response["order_status"] = 'P';
            $pp_response["reason_text"] = "Success";
            $pp_response['transaction_id'] = $txnid;
            $pp_response['customer_email'] = $email;
		}

		if (fn_check_payment_script('payumoney.php', $_REQUEST['order_id'])) {
	        fn_finish_payment($_REQUEST['order_id'], $pp_response, false);
	        fn_order_placement_routines('route', $_REQUEST['order_id']);
	    }

	} elseif($mode == 'cancel'){

		$pp_response = array();

		$status = $_REQUEST["status"];
		$firstname = $_REQUEST["firstname"];
		$amount = $_REQUEST["amount"];
		$txnid = $_REQUEST["txnid"];
		$posted_hash = $_REQUEST["hash"];
		$key = $_REQUEST["key"];
		$productinfo = $_REQUEST["productinfo"];
		$email = $_REQUEST["email"];
		$phone = $_REQUEST["phone"];

		$payment_id = db_get_field("SELECT payment_id FROM ?:orders WHERE order_id = ?i", $_REQUEST["order_id"]);
        $processor_data = fn_get_payment_method_data($payment_id);

		$salt = $processor_data['processor_params']['salt'];

		$pp_response["order_status"] = 'F';
        $pp_response["reason_text"] = "";
        $pp_response['transaction_id'] = $txnid;

        fn_order_placement_routines('checkout_redirect', $txnid);

	} elseif($mode == 'fail'){
		$pp_response = array();

		$status = $_REQUEST["status"];
		$firstname = $_REQUEST["firstname"];
		$amount = $_REQUEST["amount"];
		$txnid = $_REQUEST["txnid"];
		$posted_hash = $_REQUEST["hash"];
		$key = $_REQUEST["key"];
		$productinfo = $_REQUEST["productinfo"];
		$email = $_REQUEST["email"];
		$phone = $_REQUEST["phone"];

		$payment_id = db_get_field("SELECT payment_id FROM ?:orders WHERE order_id = ?i", $_REQUEST["order_id"]);
        $processor_data = fn_get_payment_method_data($payment_id);

		$salt = $processor_data['processor_params']['salt'];

		$pp_response["order_status"] = 'F';
        $pp_response["reason_text"] = "";
        $pp_response['transaction_id'] = $txnid;

        fn_order_placement_routines('checkout_redirect', $txnid);
	}

} else{

	$payu_account = $processor_data['processor_params']['account'];
    $salt = $processor_data['processor_params']['salt'];
	
	//$payu_account = 'gtKFFx';
    //$salt = 'eCwWELxi';

	$current_location = Registry::get('config.current_location');

	if ($processor_data['processor_params']['mode'] == 'test') {
		$payu_url = "https://test.payu.in/_payment.php";
	} else {
		$payu_url = "https://secure.payu.in/_payment.php";
	}

	$payu_order_id = $order_id;

    $posted = array();

    $posted['key'] = $payu_account;
    $posted['txnid'] = $payu_order_id;

    $posted['amount'] = (int)$order_info['total'];
    $posted['productinfo'] = "info";
    $posted['firstname'] = $order_info['b_firstname'];
    $posted['email'] = $order_info['email'];

    $hashSequence = "key|txnid|amount|productinfo|firstname|email|udf1|udf2|udf3|udf4|udf5|udf6|udf7|udf8|udf9|udf10";
    $hashVarsSeq = explode('|', $hashSequence);
    $hash_string = '';
    foreach($hashVarsSeq as $hash_var) {
        $hash_string .= isset($posted[$hash_var]) ? $posted[$hash_var] : '';
        $hash_string .= '|';
    }
    $hash_string .= $salt;
	$hash = strtolower(hash('sha512', $hash_string));

	$posted['hash']=$hash;
        
	$msg = fn_get_lang_var('text_cc_processor_connection');
	$msg = str_replace('[processor]', 'PayU', $msg);

	$furl =  fn_url("payment_notification.fail&payment=payumoney&order_id=$order_id", AREA, 'current');
	$curl =  fn_url("payment_notification.cancel&payment=payumoney&order_id=$order_id", AREA, 'current');
	$surl =  fn_url("payment_notification.success&payment=payumoney&order_id=$order_id", AREA, 'current');

	$posted['furl'] = $furl;
    $posted['curl'] = $curl;
    $posted['surl'] = $surl;
	
    $posted['lastname'] = $order_info['b_lastname'];
    $posted['address1'] = $order_info['b_address'];
    $posted['address2'] = $order_info['b_address_2'];
    $posted['country'] = $order_info['b_country'];
    $posted['city'] = $order_info['b_city'];
    $posted['state'] = $order_info['b_state'];
    $posted['zipcode'] = $order_info['b_zipcode'];
    $posted['phone'] = $order_info['phone'];
    $posted['service_provider'] = "payu_paisa";

	fn_create_payment_form($payu_url, $posted, 'Payumoney');
    exit;
}